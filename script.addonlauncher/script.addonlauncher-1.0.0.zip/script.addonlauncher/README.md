# script.addonLauncher
# アドオン起動ツール

動画再生中にプログラムアドオンを起動するためのツール
Keymap EditorでこのアドオンをFullscreen Video, Fullscreen Live TVで起動するようにキー（Menuボタンなど)を割り当ててください。

## 使い方

 1. プログラムアドオンの選択画面が表示される
 1. 選択ボタンでアドオンが起動する

