﻿import xbmcaddon
import xbmc
import simplejson as json
import xbmcgui

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_version = addon.getAddonInfo('version')

def sendJSON(method, json_params = {}):

    #This the generated JSON-RPC query code
    params = json.dumps({"jsonrpc":"2.0",
                         "method": method,
                         "params": json_params,
                         "id":0})

    #Response data is a binary string and I want to read it easily
    responseObject = xbmc.executeJSONRPC(params)

    return json.loads(responseObject).get("result")

def addon_log(string):
    if not isinstance(string, str):
        string = str(string)
    try:
        log_message = string
    except:
        log_message = 'addonException: addon_log: %s' %format_exc()
    # for ease in development change the level to LOGNOTICE
    xbmc.log("[%s-%s]: %s" %(addon_id, addon_version, log_message), level=xbmc.LOGINFO)

def main():
    params = {
        "type": "xbmc.python.script",
        "enabled": True,
        "properties": ['name', 'thumbnail']
    }
    item_result = sendJSON("Addons.GetAddons", params)
    if item_result and "addons" in item_result:
        objs = item_result['addons']
        dialog = xbmcgui.Dialog()
        lists = []
        for addon in objs:
            item = xbmcgui.ListItem(addon['name'])
            item.setArt({"icon": addon['thumbnail'], "thumb": addon['thumbnail']})
            lists.append(item)
        index = dialog.select("Execute", lists, useDetails=True)
        if index >= 0:
            id = objs[index]['addonid']
            #exec
            xbmc.executebuiltin(f'RunAddon({id})')
    else:
        addon_log("No addon")
        return
    

if (__name__ == "__main__"):
    addon_log('script starting')
    main()

addon_log('script finished')
