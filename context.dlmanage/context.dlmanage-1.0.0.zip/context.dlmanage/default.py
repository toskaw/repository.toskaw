import sys
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon

# 本体の共通文字用 (Core)
_core = xbmc.getLocalizedString

# 自作アドオンの文字用 (Addon)
_addon = xbmcaddon.Addon().getLocalizedString

# 削除したい特定のファイル名を指定
TARGET_FILE_NAME = "dl.sh"

def main():
    selected_item = sys.listitem
    if not selected_item:
        return

    folder_path = selected_item.getPath()
    if not folder_path:
        return
    
    # パスの末尾がスラッシュで終わるように調整
    if not folder_path.endswith("/"):
        folder_path += "/"

    progress = xbmcgui.DialogProgress()
    progress.create(_addon(30000), _core(194))

    files = find_files_recursive_vfs(folder_path, TARGET_FILE_NAME, progress)
    if progress.iscanceled():
        return
    progress.close()
    path_list = []
    if not files:
        xbmcgui.Dialog().ok(_core(283), _core(284))
        return
    
    for file in files:
        path_list.append(file['path'])
        
    dialog = xbmcgui.Dialog()
    indexs = dialog.multiselect(_addon(30001), path_list)
    if not indexs:
        return
    for index in indexs:
        delete(files[index]['path'])
    
def delete(path):
    dialog = xbmcgui.Dialog()
    confirmed = dialog.yesno(
        _core(122),
        _core(125) + f"\n'{path}'"
    )
        
    if confirmed:
        # xbmcvfs.delete でファイルを削除
        if xbmcvfs.delete(path):
            dialog.notification(_addon(30002), _addon(30003).format(TARGET_FILE_NAME), xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        else:
            dialog.ok(_addon(30004), _addon(30005))

def find_files_recursive_vfs(root_path, extensions, dialog):
    """
    xbmcvfs を使用して、指定されたフォルダー配下を再帰的に検索します。
    ローカルパスだけでなく、smb:// や nfs:// などのネットワークパスにも対応します。
    """
    file_list = []

    # Kodiのパス区切り文字を適切に補正
    if not root_path.endswith('/') and not root_path.endswith('\\'):
        # SMBなどのネットワークパスは通常フォワードスラッシュ「/」
        root_path += '/'

    try:
        # xbmcvfs.listdir は (dirs, files) のタプルを返す
        dirs, files = xbmcvfs.listdir(root_path)
    except Exception as e:
        xbmc.log(f"[Context-Search] リスト取得に失敗: {root_path} - エラー: {str(e)}", xbmc.LOGERROR)
        return file_list

    # 1. 現在のフォルダー内にあるファイルをチェック
    for file in files:
        if file.lower().endswith(extensions):
            # パスを結合（xbmcvfs.makeLegalFilename を経由させるとより確実）
            full_path = root_path + file
            file_list.append({
                "name": file,
                "path": full_path
            })
    if dialog.iscanceled():
        return []
    # 2. サブフォルダーを再帰的に掘り下げて検索
    for sub_dir in dirs:
        sub_folder_path = root_path + sub_dir + '/'
        # 自身を呼び出して下位層のファイルリストをマージ
        sub_files = find_files_recursive_vfs(sub_folder_path, extensions, dialog)
        file_list.extend(sub_files)
        if dialog.iscanceled():
            return []
    return file_list

if __name__ == '__main__':
    main()
