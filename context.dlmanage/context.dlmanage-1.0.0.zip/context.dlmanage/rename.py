import sys
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import json
import os
import re

# 本体の共通文字用 (Core)
_core = xbmc.getLocalizedString

# 自作アドオンの文字用 (Addon)
_addon = xbmcaddon.Addon().getLocalizedString

import xbmc
import json

def get_video_playlist_items():
    # JSON-RPCのクエリを作成 (Playlist.GetItems)
    # properties に取得したいメタデータ（title, file, thumbnail, plot等）を指定します
    query = {
        "jsonrpc": "2.0",
        "method": "Playlist.GetItems",
        "params": {
            "playlistid": 1,  # 1 はビデオプレイリスト (0 は音楽)
            "properties": ["title", "file", "thumbnail", "plot"]
        },
        "id": 1
    }
    
    # クエリを実行
    response_str = xbmc.executeJSONRPC(json.dumps(query))
    response = json.loads(response_str)
    
    # アイテム一覧の抽出
    if "result" in response and "items" in response["result"]:
        items = response["result"]["items"]
            
        return items
    return []


def get_tv_numbers():
    addon = xbmcaddon.Addon()
    dialog = xbmcgui.Dialog()
    
    # 前回の設定値をデフォルト値として読み込む
    default_season = addon.getSetting('season_number') or "1"
    default_episode = addon.getSetting('episode_number') or "1"
    
    # 1. シーズン番号の入力 
    season_str = dialog.numeric(0, _addon(30006), default_season)
        
    # 2. エピソード番号の入力
    episode_str = dialog.numeric(0, _addon(30007), default_episode)
    
    # 次回のために設定へ保存
    addon.setSetting('season_number', season_str)
    addon.setSetting('episode_number', episode_str)
    
    return int(season_str), int(episode_str)


def rename_playlist_items():
    
    # playlistを取得
    playlist_items = get_video_playlist_items()

    total_items = len(playlist_items)


    if total_items == 0:
        xbmcgui.Dialog().notification('情報', 'リストが空です。', xbmcgui.NOTIFICATION_INFO)
        return

    try:
        season, start_episode = get_tv_numbers()
    except Exception as e:
        return
    
    if season is not None:
        xbmc.log(f"リネーム開始: S{season:02d}E{start_episode:02d}...", xbmc.LOGINFO)
    else:
        return

    success_count = 0
    ok = xbmcgui.Dialog().yesno(_addon(30000), _addon(30008).format(season, start_episode))
    if not ok:
        return
    
    # リストの最初から順にループして処理
    for idx, item in enumerate(playlist_items):
        # 取得した情報を使ってログ出力や処理を行う
        title = item.get("title", "No Title")
        file_path = item.get("file", "")
        xbmc.log(f"Index {idx}: {title} ({file_path})", xbmc.LOGINFO)

        episode = start_episode + idx

        # 実在する場合のみ処理
        if file_path and xbmcvfs.exists(file_path):
            directory, old_name = os.path.split(file_path)
            name, ext = os.path.splitext(old_name)
            #S00E00があったら削除
            name = re.sub(r'S\d+E\d+', '', name)
            # 例: 「元のファイル名_S01E01.mp4」のように連番を付与する規則
            new_name = f"{name}_S{season:02d}E{episode:02d}{ext}"
            new_file_path = os.path.join(directory, new_name)
            
            try:
                xbmcvfs.rename(file_path, new_file_path)
                success_count += 1
            except Exception as e:
                xbmc.log(f"Rename failed for {old_name}: {str(e)}", xbmc.LOGERROR)


    xbmcgui.Dialog().notification(_addon(30002), _addon(30009).format(success_count), xbmcgui.NOTIFICATION_INFO)
    

if __name__ == '__main__':
    rename_playlist_items()
