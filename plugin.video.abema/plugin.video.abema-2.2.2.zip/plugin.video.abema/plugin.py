import sys
from urllib.parse import parse_qsl, urlparse
import xbmcgui
import xbmcplugin
import xbmcvfs
import xbmcaddon

import simplejson as json

import re

from lib import abema
from lib import Cache
from lib import Search

from lib import log, show_info, check_if_kodi_supports_manifest, extract_info, extract_manifest_url_from_info, get_url, refresh, get_adaptive_type_from_url, localize, clear_thumbnails

_HANDLE = int(sys.argv[1])

def list_videos(category):
    xbmcplugin.setPluginCategory(_HANDLE, category)
    xbmcplugin.setContent(_HANDLE, 'movies')
    
    videos = []
    context = (localize(30020), 'save_series')

    videos = Cache().get_episodes(category)

    for video in videos:
        label = video['series_title']

        list_item = xbmcgui.ListItem(label=label, offscreen=True)
        vid_info = list_item.getVideoInfoTag()
        vid_info.setTitle(label)
        vid_info.setGenres([video['genre']])
        vid_info.setTvShowTitle(video['series_title'])
        vid_info.setMediaType('video')
        list_item.setProperty('IsPlayable', 'true')
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['fanart'], 'poster': video['fanart']})

        if context:
            context_menu_item = (context[0], 'RunPlugin({})'.format(get_url(action=context[1], series=video['series'], series_title=video['series_title'])))
            list_item.addContextMenuItems([context_menu_item])

            
        url = get_url(action='list_series', category=category, series=video['series'], series_title=video['series_title'])
        is_folder = True
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_VIDEO_TITLE)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_DATEADDED)
    xbmcplugin.endOfDirectory(_HANDLE)

def list_series(category, series, title):
    xbmcplugin.setPluginCategory(_HANDLE, title)
    xbmcplugin.setContent(_HANDLE, 'movies')

    videos = []
    context = (localize(30020), 'save_season')
    #import web_pdb; web_pdb.set_trace()
    videos = Cache().get_series_episodes(series)

    for video in videos:
        if video['episodeGroups'] :    
            for eg in video['episodeGroups']:
                label = video['name'] + "-" +  eg['name']
                list_item = xbmcgui.ListItem(label=label, offscreen=True)
        
                vid_info = list_item.getVideoInfoTag()
                vid_info.setTitle(label)
                vid_info.setGenres([category])
                vid_info.setTvShowTitle(title)
                vid_info.setMediaType('video')
                list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
                list_item.setProperty('IsPlayable', 'true')

                if context:
                    context_menu_item = (context[0], 'RunPlugin({})'.format(get_url(action=context[1], series=title, season=video['season'], group=eg['id'], title=video.get('name',""))))
                    list_item.addContextMenuItems([context_menu_item])

                url = get_url(action='list_episodes', season=video['season'], group=eg['id'], title=title)
                is_folder = True
                xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
        else:
            label = video['name']
            list_item = xbmcgui.ListItem(label=label, offscreen=True)
        
            vid_info = list_item.getVideoInfoTag()
            vid_info.setTitle(label)
            vid_info.setGenres([category])
            vid_info.setTvShowTitle(title)
            vid_info.setMediaType('video')
            list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
            list_item.setProperty('IsPlayable', 'true')

            if context:
                context_menu_item = (context[0], 'RunPlugin({})'.format(get_url(action=context[1], series=series, season=video['season'], group="None", title=label)))
                list_item.addContextMenuItems([context_menu_item])
            
            url = get_url(action='list_episodes', season=video['season'], group="None", title=title)
            is_folder = True
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_VIDEO_TITLE)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_DATEADDED)
    xbmcplugin.endOfDirectory(_HANDLE)

def list_episodes(season, group, title):
    xbmcplugin.setPluginCategory(_HANDLE, title)
    xbmcplugin.setContent(_HANDLE, 'movies')

    videos = []
    context = None

    videos = Cache().get_eg_episodes(season, group)

    for video in videos:
        label = video['name']
        list_item = xbmcgui.ListItem(label=label, offscreen=True)
        
        vid_info = list_item.getVideoInfoTag()
        vid_info.setTitle(label)
        vid_info.setTvShowTitle(title)
        vid_info.setPlot(video['desc'])
        vid_info.setMediaType('video')
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        list_item.setProperty('IsPlayable', 'true')

        url = get_url(action='play', video=video['video'])
        is_folder = False

        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_VIDEO_TITLE)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_DATEADDED)
    xbmcplugin.endOfDirectory(_HANDLE)
    
def list_live():
    xbmcplugin.setPluginCategory(_HANDLE, "live")
    xbmcplugin.setContent(_HANDLE, 'movies')
    #import web_pdb; web_pdb.set_trace()

    videos = []
    context = None

    videos = abema.get_channels()
    slots = abema.fetch_slots()

    for video in videos:
        label = video['name']
        label2 = ""
        thumb_id = ""
        thumb_name = ""
        channel = video['id']
        icon = f'https://image.p-c2-x.abema-tv.com/image/channels/{channel}/logo.png'
        for slot in slots['slots']:
            if slot['channelId'] == channel:
                label2 = slot['title']
                thumb_id = slot['thumbnails']['default']['id']
                thumb_name  = slot['thumbnails']['default']['name']
                break;

        list_item = xbmcgui.ListItem(label=label, label2=label2, offscreen=True)
        thumbnail = f'https://image.p-c2-x.abema-tv.com/image/programs/{thumb_id}/{thumb_name}.png'
        vid_info = list_item.getVideoInfoTag()
        vid_info.setTitle(label2)
        vid_info.setTvShowTitle(label2)
        #vid_info.setPlot(video['desc'])
        vid_info.setMediaType('tvshow')
        list_item.setArt({'icon': icon, 'banner': thumbnail, 'fanart': thumbnail})
        list_item.setProperty('IsPlayable', 'true')

        url = get_url(action='play_live', video=video['id'])
        is_folder = False

        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_VIDEO_TITLE)
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_DATEADDED)
    xbmcplugin.endOfDirectory(_HANDLE)
    
def get_categories():
    cats = abema.get_categories()

    return cats

def list_categories():
    xbmcplugin.setPluginCategory(_HANDLE, '...')
    xbmcplugin.setContent(_HANDLE, 'movies')

    categories = get_categories()
    for item in categories:
        list_item = xbmcgui.ListItem(label=item['name'], offscreen=True)

        vid_info = list_item.getVideoInfoTag()
        vid_info.setTitle(item['name'])
        vid_info.setGenres([item['id']])
        vid_info.setMediaType('video')

        url = get_url(action='listing', category=item['id'])
        is_folder = True
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)

    #live
    list_item = xbmcgui.ListItem(label=localize(30011), offscreen=True)
    url = get_url(action='live')
    is_folder = True
    xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)

    #search
    list_item = xbmcgui.ListItem(label=localize(30012), offscreen=True)
    url = get_url(action='search')
    is_folder = True
    xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)

    #lastplay channel
    ch = xbmcaddon.Addon().getSetting('lastchannel')
    if ch:
        videos = abema.get_channels()
        for video in videos:
            if ch == video['id']:
                label = video['name']
                icon = f'https://image.p-c2-x.abema-tv.com/image/channels/{ch}/logo.png'
                list_item = xbmcgui.ListItem(label=label, offscreen=True)
                vid_info = list_item.getVideoInfoTag()
                vid_info.setTitle(label)
                vid_info.setMediaType('tvshow')
                list_item.setArt({'icon': icon})
                list_item.setProperty('IsPlayable', 'true')
                url = get_url(action='play_live', video=ch)
                is_folder = False
                xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
                break
            
    xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(_HANDLE)

def play_video(video):
    url = f'https://abema.tv/video/episode/{video}'
    info = extract_info(url)
    url = extract_manifest_url_from_info(info)
    skip = abema.fetch_markers(video)
    #import web_pdb; web_pdb.set_trace()

    skipdata = {}
    for obj in skip:
        for k, v in obj.items():
            item = {}
            stinger = {}
            item['start'] = float(v.get('startTimeMs', 0)) / 1000
            item['end'] = float(v.get('endTimeMs', 0)) / 1000
            if k == "opening":
                skipdata['intro'] = item
            if k == "ending":
                skipdata['credits'] = item
                if item['end'] != 0 :
                    stinger['start'] = item['end']
                    stinger['end'] = 0
                    skipdata['stinger'] = stinger
            
            break
        
    adaptive_type = False

    if url:
        adaptive_type = get_adaptive_type_from_url(url)

    if not url or not check_if_kodi_supports_manifest(adaptive_type):
        err_msg = localize(33000)
        log(err_msg)
        show_info(err_msg)
        raise Exception(err_msg)

    # proxy
    res = urlparse(url)
    url = 'http://127.0.0.1:51041/video.abema/' + res.netloc + res.path
    list_item = xbmcgui.ListItem(info['title'], path=url)
    list_item.setProperty("IsPlayable","true")
    skip_json = json.dumps(skipdata)
    xbmcaddon.Addon().setSetting('skipdata', skip_json)

    if adaptive_type:
        list_item.setMimeType('application/x-mpegURL')
        list_item.setContentLookup(False)
        #list_item.setProperty('inputstream', 'inputstream.adaptive')

        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        list_item.setProperty('inputstream.ffmpegdirect.mime_type', 'application/x-mpegURL')
        #list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        #list_item.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
        #list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')

    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=list_item)

def play_live(video):
    #import web_pdb; web_pdb.set_trace()
    url = 'https://abema.tv/now-on-air/' + video
    info = extract_info(url)
    url = extract_manifest_url_from_info(info)
    slots = abema.fetch_slots()
    title = ""
    xbmcaddon.Addon().setSetting('lastchannel', video)
    
    for slot in slots['slots']:
        if slot['channelId'] == video:
            title = slot['title']
            break;
        
    adaptive_type = False

    if url:
        adaptive_type = get_adaptive_type_from_url(url)

    if not url or not check_if_kodi_supports_manifest(adaptive_type):
        err_msg = localize(33000)
        log(err_msg)
        show_info(err_msg)
        raise Exception(err_msg)

    # proxy
    res = urlparse(url)
    url = 'http://127.0.0.1:51041/live.abema/' + res.netloc + res.path
    list_item = xbmcgui.ListItem(title, path=url)
    list_item.setProperty("IsPlayable","true")
    vid_info = list_item.getVideoInfoTag()
    vid_info.setTitle(title)

    useISA = xbmcaddon.Addon().getSetting('useISA')
    list_item.setMimeType('application/x-mpegURL')
    list_item.setContentLookup(False)
    if useISA == "true":
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_config', '{"timeshift_bufferlimit":900,"hls_ignore_endlist":false, "live_delay": "30", "hls_fix_mediasequence": true, "hls_fix_discsequence":true}')
        list_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
    else:
        list_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        list_item.setProperty('inputstream.ffmpegdirect.mime_type', 'application/x-mpegURL')
        list_item.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        list_item.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
        list_item.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')

    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=list_item)
    xbmcaddon.Addon().setSetting('skipdata', '{}')

def save_series(series, title):
    title = re.sub(r'[\\/:*?"<>|]+','', title)
    path = xbmcaddon.Addon().getSetting('savefolder') + title
    
    scr = f'yt-dlp -f b --download-archive archive.txt https://abema.tv/video/title/{series}'
    try:
        if not xbmcvfs.exists(path):
            #create folder
            xbmcvfs.mkdir(path)
        path = path + '/dl.sh'
        #create dl.sh
        dl_sh = xbmcvfs.File(path, 'w')
        dl_sh.write(scr)
        dl_sh.close()
    except Exception as e:  
        xbmc.log(f"エラーが発生しました: {e}", xbmc.LOGERROR)
    return

def save_season(series, season, group, title):
    title = re.sub(r'[\\/:*?"<>|]+','', title)
    series = re.sub(r'[\\/:*?"<>|]+','', series)
    
    path = xbmcaddon.Addon().getSetting('savefolder') + series
    series_id = season.split('_')[0]
    scr = ''
    if group != 'None':
        scr = f'yt-dlp -f b --download-archive archive.txt https://abema.tv/video/title/{series_id}?s={season}'
    else:
        scr = f'yt-dlp -f b --download-archive archive.txt https://abema.tv/video/title/{series_id}'

    try:
        if not xbmcvfs.exists(path):
            #create folder
            xbmcvfs.mkdir(path)

        path = path + '/' + title
        if not xbmcvfs.exists(path):
            #create folder
            xbmcvfs.mkdir(path)
        
        path = path + '/dl.sh'
        #create dl.sh
        dl_sh = xbmcvfs.File(path, 'w')
        dl_sh.write(scr)
        dl_sh.close()
    except Exception as e:  
        xbmc.log(f"エラーが発生しました: {e}", xbmc.LOGERROR)
    return


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        action = params['action']
        if action == 'listing':
            list_videos(params['category'])
        elif action == 'play':
            play_video(params['video'])
        elif action == 'play_live':
            play_live(params['video'])
        elif action == 'list_series':
            list_series(params['category'], params['series'], params['series_title'])
        elif action == 'list_episodes':
            list_episodes(params['season'], params['group'], params['title'])
        elif action == 'save_series':
            save_series(params['series'], params['series_title'])
        elif action == 'save_season':
            save_season(params['series'], params['season'], params['group'], params.get('title',"シーズン1"))
        elif action == 'thumbnails':
            clear_thumbnails()
        elif action == 'search':
            Search().list(_HANDLE)
        elif action == 'cache':
            Cache().delete_cache()
            func = "Container.Refresh"
            xbmc.executebuiltin(func)
        elif action == 'live':
            list_live()
        else:
            raise ValueError('Invalid paramstring: {}!'.format(paramstring))
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2][1:])
